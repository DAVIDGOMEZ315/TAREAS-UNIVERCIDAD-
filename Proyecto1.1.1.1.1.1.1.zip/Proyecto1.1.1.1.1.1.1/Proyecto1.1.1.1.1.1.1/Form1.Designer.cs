﻿namespace Proyecto1._1._1._1._1._1._1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelClockRealTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.comboBoxPortSelection = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labelBaudRate = new System.Windows.Forms.Label();
            this.labelCommunicationPort = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Led3 = new System.Windows.Forms.Button();
            this.Led2 = new System.Windows.Forms.Button();
            this.Led1 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxCloseBtn_Click = new System.Windows.Forms.PictureBox();
            this.pictureBoxMinimizeBtn_Click = new System.Windows.Forms.PictureBox();
            this.Apagado = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCloseBtn_Click)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMinimizeBtn_Click)).BeginInit();
            this.SuspendLayout();
            // 
            // labelClockRealTime
            // 
            this.labelClockRealTime.AutoSize = true;
            this.labelClockRealTime.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelClockRealTime.Font = new System.Drawing.Font("Lucida Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClockRealTime.ForeColor = System.Drawing.Color.Red;
            this.labelClockRealTime.Location = new System.Drawing.Point(26, 69);
            this.labelClockRealTime.Name = "labelClockRealTime";
            this.labelClockRealTime.Size = new System.Drawing.Size(62, 22);
            this.labelClockRealTime.TabIndex = 0;
            this.labelClockRealTime.Text = "Clock";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.pictureBoxCloseBtn_Click);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBoxMinimizeBtn_Click);
            this.panel1.Location = new System.Drawing.Point(8, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(549, 66);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(439, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Iluminacion Automatica De Escalera";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(25, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(159, 41);
            this.panel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(50, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Joel Mojarro";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Controls.Add(this.comboBoxBaudRate);
            this.panel3.Controls.Add(this.comboBoxPortSelection);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.labelBaudRate);
            this.panel3.Controls.Add(this.labelCommunicationPort);
            this.panel3.Location = new System.Drawing.Point(25, 192);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(159, 163);
            this.panel3.TabIndex = 3;
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Location = new System.Drawing.Point(20, 70);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.Size = new System.Drawing.Size(115, 21);
            this.comboBoxBaudRate.TabIndex = 5;
            // 
            // comboBoxPortSelection
            // 
            this.comboBoxPortSelection.FormattingEnabled = true;
            this.comboBoxPortSelection.Location = new System.Drawing.Point(20, 28);
            this.comboBoxPortSelection.Name = "comboBoxPortSelection";
            this.comboBoxPortSelection.Size = new System.Drawing.Size(115, 21);
            this.comboBoxPortSelection.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(20, 129);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 26);
            this.button2.TabIndex = 3;
            this.button2.Text = "Refresh Ports";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Cyan;
            this.button1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(20, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 26);
            this.button1.TabIndex = 2;
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelBaudRate
            // 
            this.labelBaudRate.AutoSize = true;
            this.labelBaudRate.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBaudRate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelBaudRate.Location = new System.Drawing.Point(45, 52);
            this.labelBaudRate.Name = "labelBaudRate";
            this.labelBaudRate.Size = new System.Drawing.Size(71, 15);
            this.labelBaudRate.TabIndex = 1;
            this.labelBaudRate.Text = "Baud Rate";
            // 
            // labelCommunicationPort
            // 
            this.labelCommunicationPort.AutoSize = true;
            this.labelCommunicationPort.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCommunicationPort.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelCommunicationPort.Location = new System.Drawing.Point(12, 7);
            this.labelCommunicationPort.Name = "labelCommunicationPort";
            this.labelCommunicationPort.Size = new System.Drawing.Size(135, 15);
            this.labelCommunicationPort.TabIndex = 0;
            this.labelCommunicationPort.Text = "Communication Port";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Location = new System.Drawing.Point(292, 220);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(118, 135);
            this.panel4.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel5.Controls.Add(this.Apagado);
            this.panel5.Controls.Add(this.Led3);
            this.panel5.Controls.Add(this.Led2);
            this.panel5.Controls.Add(this.Led1);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Location = new System.Drawing.Point(292, 79);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(265, 135);
            this.panel5.TabIndex = 5;
            // 
            // Led3
            // 
            this.Led3.BackColor = System.Drawing.Color.Red;
            this.Led3.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Led3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Led3.Location = new System.Drawing.Point(188, 85);
            this.Led3.Name = "Led3";
            this.Led3.Size = new System.Drawing.Size(67, 21);
            this.Led3.TabIndex = 5;
            this.Led3.Text = "Led 3";
            this.Led3.UseVisualStyleBackColor = false;
            this.Led3.Click += new System.EventHandler(this.Led3_Click);
            // 
            // Led2
            // 
            this.Led2.BackColor = System.Drawing.Color.Lime;
            this.Led2.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Led2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Led2.Location = new System.Drawing.Point(106, 84);
            this.Led2.Name = "Led2";
            this.Led2.Size = new System.Drawing.Size(75, 23);
            this.Led2.TabIndex = 4;
            this.Led2.Text = "Led 2";
            this.Led2.UseVisualStyleBackColor = false;
            this.Led2.Click += new System.EventHandler(this.Led2_Click);
            // 
            // Led1
            // 
            this.Led1.BackColor = System.Drawing.Color.Blue;
            this.Led1.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Led1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Led1.Location = new System.Drawing.Point(14, 84);
            this.Led1.Name = "Led1";
            this.Led1.Size = new System.Drawing.Size(75, 23);
            this.Led1.TabIndex = 3;
            this.Led1.Text = "Led 1";
            this.Led1.UseVisualStyleBackColor = false;
            this.Led1.Click += new System.EventHandler(this.Led1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.labelClockRealTime);
            this.panel6.Location = new System.Drawing.Point(413, 220);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(144, 135);
            this.panel6.TabIndex = 6;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel7.Controls.Add(this.panel4);
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel6);
            this.panel7.Controls.Add(this.panel5);
            this.panel7.Controls.Add(this.panel1);
            this.panel7.Location = new System.Drawing.Point(228, 7);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(560, 360);
            this.panel7.TabIndex = 7;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.listBox1);
            this.panel9.Location = new System.Drawing.Point(8, 76);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(275, 279);
            this.panel9.TabIndex = 7;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel8.Controls.Add(this.panel12);
            this.panel8.Controls.Add(this.panel11);
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Controls.Add(this.panel3);
            this.panel8.Controls.Add(this.panel2);
            this.panel8.Location = new System.Drawing.Point(7, 7);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(215, 360);
            this.panel8.TabIndex = 8;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel10.Controls.Add(this.label6);
            this.panel10.Controls.Add(this.pictureBox6);
            this.panel10.Location = new System.Drawing.Point(25, 54);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(159, 38);
            this.panel10.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel11.Controls.Add(this.label7);
            this.panel11.Controls.Add(this.pictureBox7);
            this.panel11.Location = new System.Drawing.Point(25, 98);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(159, 41);
            this.panel11.TabIndex = 5;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel12.Controls.Add(this.label8);
            this.panel12.Controls.Add(this.pictureBox8);
            this.panel12.Location = new System.Drawing.Point(25, 145);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(159, 41);
            this.panel12.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(50, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Julio Mendoza";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(45, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Jesus Hernandez";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(50, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Alexis Arellano";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(21, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "HORA";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.listBox1.Font = new System.Drawing.Font("Lucida Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 14;
            this.listBox1.Location = new System.Drawing.Point(52, 64);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(172, 186);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(39, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 22);
            this.label4.TabIndex = 1;
            this.label4.Text = "Detector De Equipos";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Imagen_de_WhatsApp_2025_11_30_a_las_18_18_01_c75c2dc9;
            this.pictureBox8.Location = new System.Drawing.Point(3, 6);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(41, 35);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_180716;
            this.pictureBox7.Location = new System.Drawing.Point(3, 6);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(41, 35);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Imagen_de_WhatsApp_2025_11_30_a_las_18_06_07_0ff5cfdc;
            this.pictureBox6.Location = new System.Drawing.Point(3, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(41, 35);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Imagen_de_WhatsApp_2025_11_30_a_las_17_56_44_8406660c;
            this.pictureBox1.Location = new System.Drawing.Point(3, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_171434;
            this.pictureBox2.Location = new System.Drawing.Point(3, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(112, 102);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_163220;
            this.pictureBox5.Location = new System.Drawing.Point(194, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 80);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_163118;
            this.pictureBox4.Location = new System.Drawing.Point(116, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 80);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_162943;
            this.pictureBox3.Location = new System.Drawing.Point(24, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 80);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBoxCloseBtn_Click
            // 
            this.pictureBoxCloseBtn_Click.Image = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_163525;
            this.pictureBoxCloseBtn_Click.Location = new System.Drawing.Point(499, 3);
            this.pictureBoxCloseBtn_Click.Name = "pictureBoxCloseBtn_Click";
            this.pictureBoxCloseBtn_Click.Size = new System.Drawing.Size(40, 24);
            this.pictureBoxCloseBtn_Click.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCloseBtn_Click.TabIndex = 1;
            this.pictureBoxCloseBtn_Click.TabStop = false;
            this.pictureBoxCloseBtn_Click.Click += new System.EventHandler(this.pictureBoxCloseBtn_Click_Click);
            // 
            // pictureBoxMinimizeBtn_Click
            // 
            this.pictureBoxMinimizeBtn_Click.BackgroundImage = global::Proyecto1._1._1._1._1._1._1.Properties.Resources.Captura_de_pantalla_2025_11_30_163514;
            this.pictureBoxMinimizeBtn_Click.Location = new System.Drawing.Point(453, 3);
            this.pictureBoxMinimizeBtn_Click.Name = "pictureBoxMinimizeBtn_Click";
            this.pictureBoxMinimizeBtn_Click.Size = new System.Drawing.Size(40, 24);
            this.pictureBoxMinimizeBtn_Click.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMinimizeBtn_Click.TabIndex = 2;
            this.pictureBoxMinimizeBtn_Click.TabStop = false;
            this.pictureBoxMinimizeBtn_Click.Click += new System.EventHandler(this.pictureBoxMinimizeBtn_Click_Click);
            // 
            // Apagado
            // 
            this.Apagado.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apagado.Location = new System.Drawing.Point(106, 109);
            this.Apagado.Name = "Apagado";
            this.Apagado.Size = new System.Drawing.Size(75, 23);
            this.Apagado.TabIndex = 6;
            this.Apagado.Text = "Apagado";
            this.Apagado.UseVisualStyleBackColor = true;
            this.Apagado.Click += new System.EventHandler(this.Apagado_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(797, 374);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCloseBtn_Click)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMinimizeBtn_Click)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelClockRealTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxMinimizeBtn_Click;
        private System.Windows.Forms.PictureBox pictureBoxCloseBtn_Click;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox comboBoxBaudRate;
        private System.Windows.Forms.ComboBox comboBoxPortSelection;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelBaudRate;
        private System.Windows.Forms.Label labelCommunicationPort;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Led3;
        private System.Windows.Forms.Button Led2;
        private System.Windows.Forms.Button Led1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Apagado;
    }
}

